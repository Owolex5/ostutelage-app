(()=>{var e={};e.id=23,e.ids=[23],e.modules={10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},79646:e=>{"use strict";e.exports=require("child_process")},55511:e=>{"use strict";e.exports=require("crypto")},14985:e=>{"use strict";e.exports=require("dns")},94735:e=>{"use strict";e.exports=require("events")},29021:e=>{"use strict";e.exports=require("fs")},79748:e=>{"use strict";e.exports=require("fs/promises")},81630:e=>{"use strict";e.exports=require("http")},55591:e=>{"use strict";e.exports=require("https")},91645:e=>{"use strict";e.exports=require("net")},21820:e=>{"use strict";e.exports=require("os")},33873:e=>{"use strict";e.exports=require("path")},27910:e=>{"use strict";e.exports=require("stream")},34631:e=>{"use strict";e.exports=require("tls")},79551:e=>{"use strict";e.exports=require("url")},28354:e=>{"use strict";e.exports=require("util")},74075:e=>{"use strict";e.exports=require("zlib")},71717:(e,t,r)=>{"use strict";r.r(t),r.d(t,{patchFetch:()=>y,routeModule:()=>g,serverHooks:()=>h,workAsyncStorage:()=>f,workUnitAsyncStorage:()=>x});var o={};r.r(o),r.d(o,{POST:()=>m});var s=r(42706),i=r(28203),a=r(45994),n=r(39187),p=r(98721),l=r(79748),c=r.n(l),u=r(33873),d=r.n(u);async function m(e){try{let t=await e.formData(),r=t.get("name"),o=t.get("email"),s=t.get("phone")||"Not provided",i=t.get("experience"),a=t.get("portfolio");if(!r||!o||!i||!a)return n.NextResponse.json({message:"Missing required fields: name, email, experience, and portfolio are required"},{status:400});if(!["application/pdf","application/msword","application/vnd.openxmlformats-officedocument.wordprocessingml.document","application/vnd.openxmlformats-officedocument.presentationml.presentation","image/jpeg","image/png","image/gif"].includes(a.type))return n.NextResponse.json({message:"Please upload a PDF, Word document, PowerPoint, or image file for your portfolio"},{status:400});let l=await a.arrayBuffer(),u=Buffer.from(l),m=a.name||`portfolio-${Date.now()}.pdf`,g=d().join(process.cwd(),"tmp",`portfolio-${Date.now()}-${d().extname(m)}`);await c().mkdir(d().dirname(g),{recursive:!0}),await c().writeFile(g,u);let f=p.createTransport({host:process.env.SMTP_HOST||"smtp.gmail.com",port:Number(process.env.SMTP_PORT)||587,secure:"465"===process.env.SMTP_PORT,auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASS}});return await f.sendMail({from:`"OsTutelage Careers" <${process.env.SMTP_USER}>`,to:"info@ostutelage.tech",subject:`New Writer Application from ${r}`,html:`
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f9fafb;">
          <h2 style="color: #1f2937; font-size: 24px; margin-bottom: 20px;">New Writer Application</h2>
          <p style="color: #4b5563; margin-bottom: 10px;"><strong>Name:</strong> ${r}</p>
          <p style="color: #4b5563; margin-bottom: 10px;"><strong>Email:</strong> ${o}</p>
          <p style="color: #4b5563; margin-bottom: 10px;"><strong>Phone:</strong> ${s}</p>
          <p style="color: #4b5563; margin-bottom: 10px;"><strong>Writing Experience:</strong> ${i}</p>
          <p style="color: #4b5563; margin-bottom: 20px;">
            <strong>Portfolio:</strong> ${m}<br>
            Please find the applicant's portfolio or sample work attached.
          </p>
          <p style="color: #4b5563; font-size: 14px; margin-top: 20px;">
            Sent from OsTutelage Academy Careers
          </p>
        </div>
      `,attachments:[{filename:m,path:g,contentType:a.type}]}),await f.sendMail({from:`"OsTutelage Academy" <${process.env.SMTP_USER}>`,to:o,subject:"Thank You for Your Writer Application",html:`
        <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);">
          <div style="text-align: center; margin-bottom: 20px;">
            <h1 style="color: #1f2937; font-size: 28px; font-weight: 700; margin: 0;">Thank You, ${r}!</h1>
            <p style="color: #4b5563; font-size: 16px; margin: 10px 0;">Your Writer Application Has Been Received</p>
          </div>
          <div style="background-color: #f9fafb; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
            <p style="color: #4b5563; font-size: 16px; line-height: 1.6; margin: 0 0 10px;">
              We're excited to receive your application to write for OsTutelage Academy! Our team is reviewing your submission, including your portfolio or sample work. We'll get back to you soon with the next steps.
            </p>
            <p style="color: #4b5563; font-size: 16px; line-height: 1.6; margin: 0 0 10px;">
              Your writing samples help us understand your style and expertise. We're looking forward to potentially collaborating with you!
            </p>
            <p style="color: #4b5563; font-size: 16px; line-height: 1.6; margin: 0;">
              In the meantime, explore our <a href="https://ostutelage.tech/schools" style="color: #3b82f6; text-decoration: none; font-weight: 600;">programs</a> or reach out with any questions.
            </p>
          </div>
          <div style="text-align: center; margin-bottom: 20px;">
            <a href="https://wa.me/2349036508361" style="display: inline-flex; align-items: center; gap: 8px; padding: 10px 20px; background-color: #25D366; color: #ffffff; text-decoration: none; font-weight: 600; border-radius: 8px;">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path>
              </svg>
              Contact Us via WhatsApp
            </a>
          </div>
          <div style="text-align: center; border-top: 1px solid #e5e7eb; padding-top: 20px;">
            <p style="color: #6b7280; font-size: 14px; margin: 0;">
              OsTutelage Academy<br />
              <a href="mailto:info@ostutelage.tech" style="color: #3b82f6; text-decoration: none;">info@ostutelage.tech</a> | 
              <a href="https://ostutelage.tech" style="color: #3b82f6; text-decoration: none;">ostutelage.tech</a>
            </p>
          </div>
        </div>
      `}),await c().unlink(g).catch(console.error),n.NextResponse.json({message:"Writer application sent successfully! You'll receive a confirmation email shortly."},{status:200})}catch(e){console.error("Error processing writer application:",e);try{let e=d().join(process.cwd(),"tmp");if(await c().access(e).then(()=>!0).catch(()=>!1))for(let t of(await c().readdir(e)))t.startsWith("portfolio-")&&await c().unlink(d().join(e,t)).catch(()=>{})}catch(e){console.error("Cleanup error:",e)}return n.NextResponse.json({message:"Failed to process writer application. Please try again or contact us directly.",...!1},{status:500})}}let g=new s.AppRouteRouteModule({definition:{kind:i.RouteKind.APP_ROUTE,page:"/(site)/api/career/write/route",pathname:"/api/career/write",filename:"route",bundlePath:"app/(site)/api/career/write/route"},resolvedPagePath:"C:\\Users\\owola\\Downloads\\ostutelage-app2\\app\\(site)\\api\\career\\write\\route.ts",nextConfigOutput:"",userland:o}),{workAsyncStorage:f,workUnitAsyncStorage:x,serverHooks:h}=g;function y(){return(0,a.patchFetch)({workAsyncStorage:f,workUnitAsyncStorage:x})}},96487:()=>{},78335:()=>{}};var t=require("../../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),o=t.X(0,[638,452,721],()=>r(71717));module.exports=o})();
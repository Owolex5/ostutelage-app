"use strict";(()=>{var e={};e.id=384,e.ids=[384],e.modules={75600:e=>{e.exports=require("next/dist/compiled/next-server/pages-api.runtime.prod.js")},96762:(e,t)=>{Object.defineProperty(t,"M",{enumerable:!0,get:function(){return function e(t,r){return r in t?t[r]:"then"in t&&"function"==typeof t.then?t.then(t=>e(t,r)):"function"==typeof t&&"default"===r?t:void 0}}})},93103:(e,t,r)=>{r.r(t),r.d(t,{config:()=>p,default:()=>c,routeModule:()=>d});var o={};r.r(o),r.d(o,{default:()=>u});var s=r(89947),n=r(2706),a=r(96762);let i=require("nodemailer");var l=r.n(i);async function u(e,t){if("POST"!==e.method)return t.status(405).json({message:"Method not allowed"});let{name:r,email:o,subject:s,message:n,whatsapp:a}=e.body;if(!r||!o||!s||!n)return t.status(400).json({message:"Please fill all required fields."});try{let i=l().createTransport({host:"smtp.gmail.com",port:465,secure:!0,auth:{user:process.env.EMAIL_USER,pass:process.env.EMAIL_PASS}});return await i.sendMail({from:`"${r}" <${o}>`,to:"info@ostutelage.tech",subject:`[Contact Form] ${s}`,html:`
        <h3>New Message from Contact Form</h3>
        <p><strong>Name:</strong> ${r}</p>
        <p><strong>Email:</strong> ${o}</p>
        <p><strong>Phone:</strong> ${e.body.phone||"N/A"}</p>
        <p><strong>WhatsApp:</strong> ${a}</p>
        <p><strong>Message:</strong><br/>${n}</p>
      `}),await i.sendMail({from:'"Ostutelage Team" <info@ostutelage.tech>',to:o,subject:"We Received Your Message",html:`
        <div style="font-family:sans-serif;line-height:1.5;color:#333">
          <h2 style="color:#0070f3;">Hello ${r},</h2>
          <p>Thank you for contacting Ostutelage. We have received your message:</p>
          <blockquote style="border-left:4px solid #0070f3; margin:1rem 0; padding-left:1rem; color:#555;">
            ${n}
          </blockquote>
          <p>Our team will get back to you shortly. If you checked WhatsApp, we may contact you there as well.</p>
          <p>Best regards,<br/>Ostutelage Team</p>
        </div>
      `}),t.status(200).json({message:"Message sent successfully!"})}catch(e){return console.error("Contact API Error:",e),t.status(500).json({message:"Error sending message."})}}let c=(0,a.M)(o,"default"),p=(0,a.M)(o,"config"),d=new s.PagesAPIRouteModule({definition:{kind:n.A.PAGES_API,page:"/api/contactsx",pathname:"/api/contactsx",bundlePath:"",filename:""},userland:o})},2706:(e,t)=>{Object.defineProperty(t,"A",{enumerable:!0,get:function(){return r}});var r=function(e){return e.PAGES="PAGES",e.PAGES_API="PAGES_API",e.APP_PAGE="APP_PAGE",e.APP_ROUTE="APP_ROUTE",e.IMAGE="IMAGE",e}({})},89947:(e,t,r)=>{e.exports=r(75600)}};var t=require("../../webpack-api-runtime.js");t.C(e);var r=t(t.s=93103);module.exports=r})();